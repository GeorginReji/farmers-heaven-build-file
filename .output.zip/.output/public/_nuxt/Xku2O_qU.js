import{c as a,a as n,o}from"./B-ZvT76U.js";const l={__name:"index",setup(s){return(t,e)=>(o(),a("div",null,e[0]||(e[0]=[n("h1",null,"This is admin home page",-1)])))}};export{l as default};
