import{a as o}from"./CUqWVqg6.js";import{am as t}from"./CmBRmgt-.js";/* empty css        */const f=t((a,e)=>{o().loadFromLocalStorage()});export{f as default};
