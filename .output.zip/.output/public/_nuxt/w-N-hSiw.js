import"./Csoyi7LT.js";const r=""+new URL("TFH_logo.B0JQnZIR.png",import.meta.url).href;export{r as _};
