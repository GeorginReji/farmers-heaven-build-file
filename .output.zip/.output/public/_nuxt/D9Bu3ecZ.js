import{a as o}from"./CrSWzofL.js";import{am as t}from"./Csoyi7LT.js";/* empty css        */const f=t((a,e)=>{o().loadFromLocalStorage()});export{f as default};
