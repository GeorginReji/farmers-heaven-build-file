import{a as o}from"./CCPES16T.js";import{aq as t}from"./DFAgv-iN.js";/* empty css        */const f=t((a,e)=>{o().loadFromLocalStorage()});export{f as default};
