import{a as o}from"./BZZDIO4x.js";import{aq as t}from"./CjN6I7Zp.js";/* empty css        */const f=t((a,e)=>{o().loadFromLocalStorage()});export{f as default};
