import{u as o}from"./DC4LSXyU.js";import{aq as t}from"./D8HrVBbQ.js";/* empty css        */const f=t((e,r)=>{o().loadFromLocalStorage()});export{f as default};
