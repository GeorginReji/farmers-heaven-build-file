import{a as o}from"./B9e-H73B.js";import{am as t}from"./B-ZvT76U.js";/* empty css        */const f=t((a,e)=>{o().loadFromLocalStorage()});export{f as default};
