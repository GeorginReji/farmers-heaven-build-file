import{u as o}from"./DmR5AzNR.js";import{al as t}from"./RojY1wbY.js";/* empty css        */const f=t((a,e)=>{o().loadFromLocalStorage()});export{f as default};
