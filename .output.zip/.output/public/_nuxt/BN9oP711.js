import{u as o}from"./ByHQREIO.js";import{aq as t}from"./D-yv-SCU.js";/* empty css        */const f=t((e,r)=>{o().loadFromLocalStorage()});export{f as default};
